<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\HomeController;

Route::get('',[HomeController::class, 'index'])->name('index');
Route::get('charts',[HomeController::class, 'charts'])->name('charts');
Route::get('widgets',[HomeController::class, 'widgets'])->name('widgets');
Route::get('tables',[HomeController::class, 'tables'])->name('tables');
Route::get('grid',[HomeController::class, 'grid'])->name('grid');
Route::get('form_basic',[HomeController::class, 'form_basic'])->name('form_basic');
Route::get('form_wizard',[HomeController::class, 'form_wizard'])->name('form_wizard');
Route::get('pages_buttons',[HomeController::class, 'pages_buttons'])->name('pages_buttons');
Route::get('icon_material',[HomeController::class, 'icon_material'])->name('icon_material');
Route::get('icon_fontawesome',[HomeController::class, 'icon_fontawesome'])->name('icon_fontawesome');

Route::get('pages_elements',[HomeController::class, 'pages_elements'])->name('pages_elements');

Route::get('index2',[HomeController::class, 'index2'])->name('index2');

Route::get('pages_gallery',[HomeController::class, 'pages_gallery'])->name('pages_gallery');

Route::get('pages_caledar',[HomeController::class, 'pages_calendar'])->name('pages_calendar');

Route::get('pages_invoice',[HomeController::class, 'pages_invoice'])->name('pages_invoice');

Route::get('pages_chat',[HomeController::class, 'pages_chat'])->name('pages_chat');

Route::get('authentication_login',[HomeController::class, 'authentication_login'])->name('authentication_login');

Route::get('authentication_register',[HomeController::class, 'authentication_register'])->name('authentication_register');

Route::get('error_403',[HomeController::class, 'error_403'])->name('error_403');
Route::get('error_404',[HomeController::class, 'error_404'])->name('error_404');
Route::get('error_405',[HomeController::class, 'error_405'])->name('error_405');
Route::get('error_500',[HomeController::class, 'error_500'])->name('error_500');