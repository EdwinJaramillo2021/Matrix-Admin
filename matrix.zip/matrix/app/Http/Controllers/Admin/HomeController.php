<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HomeController extends Controller{

    public function index(){
        return view('admin.index');
    }

    public function charts(){
        return view('admin.charts');
    }

    public function widgets(){
        return view('admin.widgets');
    }

    public function tables(){
        return view('admin.tables');
    }

    public function grid(){
        return view('admin.grid');
    }

    public function form_basic(){
        return view('admin.form_basic');
    }

    public function form_wizard(){
        return view('admin.form_wizard');
    }

    public function pages_buttons(){
        return view('admin.pages_buttons');
    }

    public function icon_material(){
        return view('admin.icon_material');
    }

    public function icon_fontawesome(){
        return view('admin.icon_fontawesome');
    }

    public function pages_elements(){
        return view('admin.pages_elements');
    }

    public function index2(){
        return view('admin.index2');
    }

    public function pages_gallery(){
        return view('admin.pages_gallery');
    }

    public function pages_calendar(){
        return view('admin.pages_calendar');
    }

    public function pages_invoice(){
        return view('admin.pages_invoice');
    }

    public function pages_chat(){
        return view('admin.pages_chat');
    }

    public function authentication_login(){
        return view('admin.authentication_login');
    }

    public function authentication_register(){
        return view('admin.authentication_register');
    }

    public function error_403(){
        return view('admin.error_403');
    }

    public function error_404(){
        return view('admin.error_404');
    }

    public function error_405(){
        return view('admin.error_405');
    }

    public function error_500(){
        return view('admin.error_500');
    }
}